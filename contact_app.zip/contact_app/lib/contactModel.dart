class ContactModal
{
  String? name,number,img;
  ContactModal({this.name,this.number,this.img});
}
