import 'package:contact_app/contactModel.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import 'contacts.dart';

class ViewProfile extends StatefulWidget {
  const ViewProfile({Key? key}) : super(key: key);

  @override
  State<ViewProfile> createState() => _ViewProfileState();
}

class _ViewProfileState extends State<ViewProfile> {
  @override
  Widget build(BuildContext context) {

    int index = ModalRoute.of(context)!.settings.arguments as int;

    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.lightBlue.shade50,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10.0),
        child: SingleChildScrollView(
          child: Column(

            children: [

              ListTile(
                leading: GestureDetector(onTap: ()
                    {
                      Navigator.pop(context);
                      },
                    child: Icon(Icons.arrow_back_ios,color: Colors.blue,size: 25,)),
                title: Text("Contacts",style:GoogleFonts.arefRuqaa(color: Colors.blue,fontSize: 25),),
                trailing: Icon(Icons.edit_square,color: Colors.blue,size: 30,),
              ),
              SizedBox(height: 60),

              Stack(
                alignment: Alignment(0,-1.8),
                children:
                [
                  Container(height: 270,width: double.infinity,
                  decoration: BoxDecoration(color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(25))),
                    child: Column(
                    children: [
                      SizedBox(height: 75),
                      Text("${contact[index].name}",style: GoogleFonts.poppins(fontSize: 30,color: Colors.blue),),
                      SizedBox(height: 12),
                      Text("${contact[index].number}",style: GoogleFonts.poppins(fontSize: 12,color: Colors.blue),),
                      SizedBox(height: 12),
                      Text("${contact[index].name}${index}0${index}0${index}@gmail.com",style: GoogleFonts.poppins(fontSize: 11,color: Colors.blue),),
                      SizedBox(height: 40),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [


                            InkWell(onTap: () async {
                                Uri message = Uri(
                                  scheme: 'sms',
                                  path: '${contact[index].number}',
                                  queryParameters: {'body':' Testing : જો બકા તકલીફ તો રેહવાની જ '}
                                );
                                await launchUrl(message);
                                } ,
                                child: Tabs(Icon(Icons.message_sharp,size: 20,color: Colors.blue,))),

                            InkWell(onTap: () async {
                              String number = "tel: ${contact[index].number}";
                              await launchUrl(Uri.parse(number));
                                },
                             child: Tabs(Icon(Icons.call,size: 20,color: Colors.blue,))),

                            Tabs(Icon(Icons.videocam,size: 20,color: Colors.blue,)),

                            InkWell(onTap: () async {
                            Uri mail = Uri(
                                scheme: 'mailto',
                                path: 'enterEmail@gmail.com',
                                queryParameters: {'body':' Testing Email : જો બકા તકલીફ, તો રેહવાની જ '}
                            );
                            await launchUrl(mail);
                            } ,

                            child: Tabs(Icon(Icons.email,size: 20,color: Colors.blue,))),

                        ],)

                    ],
                    ),
                ),
                  CircleAvatar(radius: 60,backgroundColor: Colors.black),

                ],
              ),
              SizedBox(height: 15),
              Container(height: 110,
                width:double.infinity,
                decoration: BoxDecoration(color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(25)),
                    border: Border.all(color: Colors.blue.shade100),
                    boxShadow: [BoxShadow(color: Colors.lightBlue.shade100,
                        offset: Offset(0, 2),blurRadius: 3)],
                ),

                child:Column(crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 7.0,horizontal: 15),
                  child: Text("Send Whatsapp Message",style: TextStyle(color: Colors.lightBlueAccent,fontSize: 18),),
                ),
                Container(height:1,width: double.infinity,color: Colors.lightBlue.shade100),

                GestureDetector(onTap: () {
                    Share.share("Name : ${contact[index].name}\nContact : ${contact[index].number}\nEmail : ${contact[index].name}${index}0${index}0${index}@gmail.com");
                   },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 7.0,horizontal: 15),
                    child: Text("Share Contact",style: TextStyle(color: Colors.lightBlueAccent,fontSize: 18)),
                  ),
                ),
                Container(height:1,width: double.infinity,color: Colors.lightBlue.shade100),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 7.0,horizontal: 15),
                  child: Text("Add to Favorites",style: TextStyle(color: Colors.lightBlueAccent,fontSize: 18)),
                ),
              ],),),

              SizedBox(height: 15),
              Container(height: 50,width: double.infinity,alignment: Alignment.centerLeft,
                decoration: BoxDecoration(color: Colors.white,
                  boxShadow: [BoxShadow(color: Colors.lightBlue.shade100,offset: Offset(0,2),blurRadius: 3)],
                  borderRadius: BorderRadius.circular(15)
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15.0),
                  child: Text("Delete Contact",
                      style: TextStyle(color: Colors.red,fontSize: 23,wordSpacing:3,fontFamily: 'ame',fontWeight: FontWeight.bold),),
                ),),

              SizedBox(height: 15),
              Container(height: 50,width: double.infinity,alignment: Alignment.centerLeft,
                decoration: BoxDecoration(color: Colors.white,
                  boxShadow: [BoxShadow(color: Colors.lightBlue.shade100,offset: Offset(0,2),blurRadius: 3)],
                  borderRadius: BorderRadius.circular(15)
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15.0),
                  child: Text("Block Contact",
                      style: TextStyle(color: Colors.red,fontSize: 23,wordSpacing:3,fontFamily: 'ame',fontWeight: FontWeight.bold),),
                ),),


            ],
          ),
        ),
      ),

      ),
    );
  }

  Container Tabs(Icon icon)
  {
    return Container(height: 40,width: 40,
      alignment: Alignment.center,
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(5),
          boxShadow: [BoxShadow(color: Colors.lightBlue.shade50,offset: Offset(0, 8),blurRadius: 8)]
      ),
      child: icon);
  }

}
