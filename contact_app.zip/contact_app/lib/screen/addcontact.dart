import 'package:flutter/material.dart';

class AddContact extends StatefulWidget {
  const AddContact({Key? key}) : super(key: key);

  @override
  State<AddContact> createState() => _AddContactState();
}

class _AddContactState extends State<AddContact> {

  TextEditingController txtname = TextEditingController();
  TextEditingController txtnumber = TextEditingController();


  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15.0),
            child: Column(
              children: [
                SizedBox(height: 50),
                Container(height: 150,width: 150,alignment: Alignment.center,
                decoration: BoxDecoration(shape: BoxShape.circle,color: Colors.lightBlue.shade100),),
                SizedBox(height: 25),
                TextField(controller: txtname,
                  style: TextStyle(fontSize: 30,color: Colors.blue.shade600),
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    labelText: "Enter Name",
                    labelStyle: TextStyle(fontSize: 25,color: Colors.blue),
                    filled: true,
                    fillColor: Colors.lightBlue.shade50,
                    focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.blue),borderRadius: BorderRadius.circular(20)),
                    enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.blue),borderRadius: BorderRadius.circular(20)),

                  ),),
                SizedBox(height: 25),
                TextField(controller: txtname,
                  style: TextStyle(fontSize: 30,color: Colors.blue.shade600),
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    labelText: "Enter Contact",
                    labelStyle: TextStyle(fontSize: 25,color: Colors.blue),
                    filled: true,
                    fillColor: Colors.lightBlue.shade50,
                    focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.blue),borderRadius: BorderRadius.circular(20)),
                    enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.blue),borderRadius: BorderRadius.circular(20)),

                  ),),
              ],
            ),
          ),
        ),

      ),
    );
  }
}
